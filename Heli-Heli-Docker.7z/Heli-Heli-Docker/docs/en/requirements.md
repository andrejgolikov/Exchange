# Требования

Для работы необходима установка следующих продуктов последних версий:

- **[Docker Engine](https://docs.docker.com/engine/install/)**
  - При установке на Linux-ОС следует также выполнить шаги после стандартной установке, описанные в [этой статье](https://docs.docker.com/engine/install/linux-postinstall/).
- **[Docker Compose](https://docs.docker.com/compose/install/)**
 